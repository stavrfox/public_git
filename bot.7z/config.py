TOKEN = "5938896218:AAGA8xn4jg81d5beBBpHq6Zb2B8ABQ8JHeU"
exchanges = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}